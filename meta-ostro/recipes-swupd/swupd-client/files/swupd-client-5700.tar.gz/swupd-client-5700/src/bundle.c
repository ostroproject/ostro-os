/*
*   Software Updater - client side
*
*      Copyright (c) 2012-2015 Intel Corporation.
*
*   This program is free software: you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation, version 2 or later of the License.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*
*   Authors:
*         Jaime A. Garcia <jaime.garcia.naranjo@linux.intel.com>
*         Tim Pepper <timothy.c.pepper@linux.intel.com>
*
*/

#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>

#include "config.h"
#include <swupd.h>

#define MODE_RW_O (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)

/*
* list_installable_bundles()
* Parse the full manifest for the current version of the OS and print
*   all available bundles.
*/
int list_installable_bundles()
{
	struct list *list;
	struct file *file;
	struct manifest *MoM = NULL;
	int current_version;
	int ret;

	current_version = read_version_from_subvol_file("");
	swupd_curl_set_current_version(current_version);

	ret = load_manifests(current_version, current_version, "MoM", NULL, &MoM);
	if (ret != 0) {
		log_stdout("Cannot load official manifest MoM for version %i\n", current_version);
		return ret;
	}

	list = MoM->manifests;
	while (list) {
		file = list->data;
		list = list->next;
		printf("%s\n", file->filename);
	}

	free_manifest(MoM);
	return 0;
}

/* bundle_name: this is the name for the bundle we want to be loaded
* version: this is the MoM version from which we pull last changed for bundle manifest
* submanifest: where bundle manifest is going to be loaded
*
* Basically we read MoM version then get the submanifest only for our bundle (component)
* put it into submanifest pointer, then dispose MoM data.
*/
static int load_bundle_manifest(const char *bundle_name, int version, struct manifest **submanifest)
{
	struct list *sub_list = NULL;
	struct manifest *mom = NULL;
	int ret = 0;

	*submanifest = NULL;

	swupd_curl_set_current_version(version);
	ret = load_manifests(version, version, "MoM", NULL, &mom);
	if (ret != 0) {
		LOG_ERROR(NULL, "Unable to find official manifest", class_bundle, "\\*version=\"%i\"*\\", version);
		ret = EMOM_NOTFOUND;
		goto out;
	}

	ret = recurse_manifest(mom, bundle_name);
	if (ret != 0) {
		LOG_ERROR(NULL, "Unable recurse manifest", class_bundle, "\\*version=\"%i\"*\\", version);
		ret = ERECURSE_MANIFEST;
		goto free_out;
	}

	sub_list = list_head(mom->submanifests);
	if (sub_list != NULL) {
		*submanifest = sub_list->data;
		sub_list->data = NULL;
		ret = 0;
	}

free_out:
	free_manifest(mom);
out:
	return ret;
}

/* Finds out whether bundle_name is tracked bundle on
*  current system.
*/
static bool is_tracked_bundle(const char *bundle_name)
{
	struct stat statb;
	char *filename = NULL;
	bool ret = true;

	string_or_die(&filename, "%s/%s", BUNDLES_DIR, bundle_name);

	if (stat(filename, &statb) == -1)
		ret = false;

	free(filename);
	return ret;
}

/* When loading all tracked bundles into memory, they happen
 * to be hold in subs global var, for some reasons it is
 * needed to just pop out one or more of this loaded tracked
 * bundles, this function search for bundle_name into subs
 * struct and if it found then free it from the list.
 */
static int unload_tracked_bundle(const char *bundle_name)
{
	struct list *bundles;
	struct list *cur_item;
	struct sub *bundle;

	bundles = list_head(subs);
	while (bundles) {
		bundle = bundles->data;
		cur_item = bundles;
		bundles = bundles->next;
		if (strcmp(bundle->component, bundle_name) == 0) {
			/* unlink (aka untrack) matching bundle name from tracked ones */
			subs = free_bundle(cur_item);
			LOG_INFO(NULL, "Tracked bundle freed", class_bundle, "\\*component=\"%s\"*\\", bundle_name);
			return EXIT_SUCCESS;
		}
	}

	LOG_WARN(NULL, "Bundle not tracked", class_bundle, "\\*component=\"%s\"*\\", bundle_name);
	return EBUNDLE_NOT_TRACKED;
}

/* touch bundle filename in system bundles directory,
 * this is called after bundle installation to make sure bundle is kept tracked
 */
static int track_bundle_in_system(char *bundle)
{
	char *filename;
	int f;
	int ret = 0;

	string_or_die(&filename, "%s/%s", BUNDLES_DIR, bundle);

	f = open(filename, O_WRONLY | O_CREAT | O_NONBLOCK | O_NOCTTY, MODE_RW_O);
	if (f < 0) {
		LOG_ERROR(NULL, "Cannot write bundle file into system", class_bundle, "\\*filename=\"%s\"*\\", filename);
		ret = EBUNDLE_NOT_TRACKED;
	} else {
		close(f);
	}

	free(filename);

	return ret;
}

/*  This function is a fresh new implementation for a bundle
 *  remove without being tied to verify loop, this means
 *  improved speed and space as well as more roubustness and
 *  flexibility. What it does is basically:
 *
 *  1) Read MoM and load all submanifests except the one to be
 *  	removed and then consolidate them.
 *  2) Load the removed bundle submanifest.
 *  3) Order the file list by filename
 *  4) Deduplicate removed submanifest file list that happens
 *  	to be on the MoM (minus bundle to be removed).
 *  5) iterate over to be removed bundle submanifest file list
 *  	performing a unlink(2) for each filename.
 *  6) Done.
 */
int remove_bundle(const char *bundle_name)
{
	int lock_fd;
	int ret = 0;
	int current_version = CURRENT_OS_VERSION;
	struct manifest *current_mom, *bundle_manifest;

	/* Initially we don't support format nor path_prefix
	 * for bundle_rm but eventually that will be added, then
	 * set_format_string() and init_globals() must be pulled out
	 * to the caller to properly initialize in case those opts
	 * passed to the command.
	 */
	set_format_string(NULL);
	if (!init_globals())
		return EINIT_GLOBALS;

	ret = swupd_init(&lock_fd, O_RDWR);
	if (ret != 0) {
		printf("Failed updater initialization, exiting now.\n");
		return ret;
	}

	/* os-core bundle not allowed to be removed...
	 * although this is going to be caught later because of all files
	 * being marked as 'duplicated' and note removing anything
	 * anyways, better catch here and return success, no extra work to be done.
	 */
	if (strcmp(bundle_name, "os-core") == 0) {
		LOG_INFO(NULL, "s-core is not allowed to be removed from the system", class_bundle, "");
		log_stdout("os-core is not allowed to be removed from the system, exiting now.\n");
		ret = EBUNDLE_NOT_TRACKED;
		goto out_free_curl;
	}

	if (!is_tracked_bundle(bundle_name)) {
		LOG_WARN(NULL, "Not a tracked bundle", class_bundle, "\\*component=\"%s\"*\\", bundle_name);
		log_stdout("bundle %s is not installed on the system, exiting now\n", bundle_name);
		ret = EBUNDLE_NOT_TRACKED;
		goto out_free_curl;
	}

	current_version = read_version_from_subvol_file(path_prefix);
	swupd_curl_set_current_version(current_version);

	ret = load_manifests(current_version, current_version, "MoM", NULL, &current_mom);
	if (ret != 0) {
		log_stdout("Cannot load official manifest MoM for version %i\n", current_version);
		goto out_free_curl;
	}

	/* load all tracked bundles into memory */
	read_subscriptions_alt();
	/* now popout the one to be removed */
	ret =  unload_tracked_bundle(bundle_name);
	if (ret != 0) {
		LOG_ERROR(NULL, "Cannot untrack bundle", class_bundle, "\\*component=\"%s\"*\\", bundle_name);
		log_stdout("Cannot untrack bundle \"%s\", exiting now.\n", bundle_name);
		goto out_free_mom;
	}

	subscription_versions_from_MoM(current_mom, 0);
	/* load all submanifest minus the one to be removed */
	recurse_manifest(current_mom, NULL);
	consolidate_submanifests(current_mom);

	/* Now that we have the consolidated list of all files, load bundle to be removed submanifest*/
	ret = load_bundle_manifest(bundle_name, current_version, &bundle_manifest);
	if (ret != 0) {
		log_stdout("Cannot load bundle submanifest, exiting now\n");
		goto out_free_mom;
	}

	/* deduplication needs file list sorted by filename, do so */
	bundle_manifest->files = list_sort(bundle_manifest->files, file_sort_filename);
	deduplicate_files_from_manifest(&bundle_manifest, current_mom);

	log_stdout("Deleting bundle files...\n");
	remove_files_in_manifest_from_fs(bundle_manifest);

	log_stdout("Untracking bundle from system...\n");
	rm_bundle_file(bundle_name);

	LOG_INFO(NULL, "Success: Bundle removed", class_bundle, "\\*bundle_name=\"%s\",ret=\"%i\"*\\", bundle_name, ret);
	log_stdout("Success: Bundle removed\n");

	free_manifest(bundle_manifest);
out_free_mom:
	free_manifest(current_mom);
out_free_curl:

	if (ret) {
		LOG_ERROR(NULL, "Error: Bundle remove failed -", class_bundle, " bundle '%s', ret=\"%i\"*\\", bundle_name, ret);
		log_stdout("Error: Bundle remove failed\n");
	}

	swupd_curl_cleanup();
	post_unmount();
	v_lockfile(lock_fd);
	close_log();
	dump_file_descriptor_leaks();

	return ret;
}

/* Bundle install one ore more bundles passed in bundles
 * param as a null terminated array of strings
 */
int install_bundles(char **bundles)
{
	int lock_fd;
	int ret = 0;
	int current_version;
	struct manifest *mom;
	struct list *iter;
	struct sub *sub;
	struct file *file;

	/* step 1: initialize swupd and get current version from OS */

	if (!init_globals())
		return EINIT_GLOBALS;

	ret = swupd_init(&lock_fd, O_RDWR);
	if (ret != 0) {
		log_stdout("Failed updater initialization, exiting now.\n");
		return ret;
	}

	current_version = read_version_from_subvol_file(path_prefix);
	swupd_curl_set_current_version(current_version);

	/* first of all, make sure STATE_DIR is there, recreate if necessary*/
	ret = create_required_dirs();
	if (ret != 0) {
		LOG_ERROR(NULL, "Cannot recreate STATE_DIR", class_bundle, "");
		log_stdout("State directory %s cannot be recreated, aborting installation%i\n",
			STATE_DIR);
		goto clean_and_exit;
	}


	ret = load_manifests(current_version, current_version, "MoM", NULL, &mom);
	if (ret != 0) {
		log_stdout("Cannot load official manifest MoM for version %i\n", current_version);
		ret = EMOM_NOTFOUND;
		goto clean_and_exit;
	}

	/* step 2: check bundle args are valid if so populate subs struct */

	int i;
	for (i = 0; *bundles; ++bundles) {
		if (is_tracked_bundle(*bundles)) {
			log_stdout("%s bundle already installed, skipping it\n", *bundles);
			continue;
		}

		if (!manifest_has_component(mom, *bundles)) {
			log_stdout("%s bundle name is invalid, skipping it...\n", *bundles);
			continue;
		}

		if (component_subscribed(*bundles)) {
			continue;
		}
		create_and_append_subscription(*bundles);
		i++;
		log_stdout("Added bundle %s for installation\n", *bundles);
		LOG_INFO(NULL, "Added bundle for installation", class_bundle, "\\*component=\"%s\"*\\", *bundles);
	}

	if (i == 0) {
		log_stdout("There are no pending bundles to install, exiting now\n");
		LOG_INFO(NULL, "no pending bundles to install", class_bundle, "");
		ret = 0;
		goto clean_manifest_and_exit;
	}

	subscription_versions_from_MoM(mom, 0);
	recurse_manifest(mom, NULL);
	consolidate_submanifests(mom);

	/* step 3: download neccessary packs */

	ret  = rm_staging_dir_contents("download");
	if (ret != 0) {
		LOG_WARN(NULL, "cannot wipe download directory content, carrying on", class_bundle, "");
	}

	log_stdout("Downloading required packs...\n");
	ret = download_subscribed_packs(0, current_version, true);
	if (ret != 0) {
		LOG_ERROR(NULL, "zero pack downloads failed", class_bundle, "");
		log_stdout("pack downloads failed, cannot proceed with the installation, exiting.\n");
		goto clean_subs_and_exit;
	}

	/* step 4: Install all bundle(s) files into the fs */

	log_stdout("Installing bundle(s) files...\n");
	iter = list_head(mom->files);
	while (iter) {
		file = iter->data;
		iter = iter->next;

		if (file->is_deleted || file->do_not_update || ignore(file)) {
			continue;
		}

		ret = do_staging(file);
		if (ret == 0) {
			rename_staged_file_to_final(file);
		}
	}

	sync();

	/* step 5: create bundle(s) subscription entries to track them
	 *
	 * Strictly speaking each manifest has an entry to write its own bundle filename
	 * and thus tracking automagically, here just making sure.
	 */

	iter = list_head(subs);
	while (iter) {
		sub = iter->data;
		iter = iter->next;

		log_stdout("Tracking %s bundle on the system\n", sub->component);
		ret = track_bundle_in_system(sub->component);
		if (ret != 0) {
			log_stdout("Cannot track %s bundle on the system\n", sub->component);
		}
		LOG_INFO(NULL, "Bundle installed successfully", class_bundle, "\\*component=\"%s\"*\\", sub->component);
	}

	/* Run any scripts that are needed to complete update */
	run_scripts();

	ret = 0;
	LOG_INFO(NULL, "Bundle(s) installation done", class_bundle, "\\*ret=\"%i\"*\\", ret);
	log_stdout("Bundle(s) installation done.\n");

clean_subs_and_exit:
	free_subscriptions();
clean_manifest_and_exit:
	free_manifest(mom);
clean_and_exit:
	swupd_curl_cleanup();
	post_unmount();
	v_lockfile(lock_fd);
	close_log();
	dump_file_descriptor_leaks();
	free_globals();

	return ret;
}
