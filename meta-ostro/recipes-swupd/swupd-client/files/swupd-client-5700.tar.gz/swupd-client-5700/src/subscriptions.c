/*
 *   Software Updater - client side
 *
 *      Copyright © 2012-2015 Intel Corporation.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, version 2 or later of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Authors:
 *         Arjan van de Ven <arjan@linux.intel.com>
 *         Tim Pepper <timothy.c.pepper@linux.intel.com>
 *
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>

#include "config.h"
#include <swupd.h>

struct list *subs;

static void free_subscription_data(void *data)
{
	struct sub *sub = (struct sub *) data;

	free(sub->component);
	free(sub);
}


void free_subscriptions(void)
{
	list_free_list_and_data(subs, free_subscription_data);
	subs = NULL;
}

struct list *free_bundle(struct list *item)
{
	return list_free_item(item, free_subscription_data);
}

struct list *free_list_file(struct list *item)
{
	return list_free_item(item, free_file_data);
}

void read_subscriptions_alt(void)
{
	char *path = NULL;
	DIR *dir;
	struct dirent *ent;

	string_or_die(&path, "%s/%s", path_prefix, BUNDLES_DIR);

	dir = opendir(path);
	if (dir) {
		while((ent = readdir(dir))) {
			if ((strcmp(ent->d_name, ".") == 0) || (strcmp(ent->d_name, "..") == 0)) {
				continue;
			}
			if (ent->d_type == DT_REG) {
				if (component_subscribed(ent->d_name)) {
				/*  This is considered odd since means two files same name on same folder */
					LOG_DEBUG(NULL, "Bundle already loaded, skipping it", class_subscription, "%s", ent->d_name);
					continue;
				}

				create_and_append_subscription(ent->d_name);

			} else {
				/* all non regular files inside bundles dir are considered corrupted */
				LOG_WARN(NULL, "File is corrupted, skipping it", class_subscription, "%s", ent->d_name);
			}
		}

		if (closedir(dir) != 0) {
			LOG_ERROR(NULL, "Cannot close directory", class_subscription, "%s", path);
		}
	}

	free(path);

	/* if nothing was picked up from bundles directory then add os-core by default */
	if (list_len(subs) == 0) {
		LOG_INFO(NULL, "No tracked bundles found, adding default", class_subscription, "os-core");
		create_and_append_subscription("os-core");
	}
}

int component_subscribed(char *component)
{
	struct list *list;
	struct sub *sub;

	LOG_DEBUG(NULL, "Checking subscription", class_subscription, "%s", component);
	list = list_head(subs);
	while (list) {
		sub = list->data;
		list = list->next;

		if (strcmp(sub->component, component) == 0)
			return 1;
	}

	return 0;
}

int subscription_versions_from_MoM(struct manifest *MoM, int is_old)
{
	struct list *list;
	struct list *list2;
	struct file *file;
	struct sub *sub;
	bool bundle_found;
	int ret = 0;

	list = list_head(subs);
	while (list) {
		bundle_found = false;
		sub = list->data;
		list = list->next;

		list2 = MoM->manifests;
		while (list2 && !bundle_found) {
			file = list2->data;
			list2 = list2->next;

			if (strcmp(sub->component, file->filename) == 0) {
				if (is_old)
					sub->oldversion = file->last_change;
				else
					sub->version = file->last_change;
				bundle_found = true;
			}
		}

		if (!bundle_found) {
			sub->version = -1;
			LOG_ERROR(NULL, "Bundle not in MoM", class_subscription, "%s", sub->component);
			log_stdout("ERROR: Bundle not in MoM |\"component=%s\"\n", sub->component);
			ret = EBUNDLE_MISMATCH;
		}
	}

	return ret;
}

int unlink_invalid_bundles(void)
{
	struct list *bundles;
	struct list *cur_item;
	struct sub *bundle;
	int ret = 0;

	bundles = list_head(subs);
	while (bundles) {
		bundle = bundles->data;
		cur_item = bundles;
		bundles = bundles->next;
		if (bundle->version == -1) {
			LOG_INFO(NULL, "Deleting invalid local bundle", class_subscription, "%s", bundle->component);
			log_stdout("Deleting invalid local bundle: %s\n", bundle->component);

			if (rm_bundle_file(bundle->component) < 0) {
				LOG_ERROR(NULL, "cannot delete local bundle file", class_subscription, "%s", bundle->component);
				ret= EBUNDLE_REMOVE;
			}

			/* unlink and free current invalid local bundle after corresponing file deleted */
			subs = free_bundle(cur_item);
		}
	}

	return ret;
}

void create_and_append_subscription(const char *component)
{
	struct sub *sub;

	sub = calloc(1, sizeof(struct sub));
	if (!sub) {
		abort();
	}

	sub->component = strdup(component);
	if (sub->component == NULL) {
		abort();
	}

	sub->version = 0;
	sub->oldversion = 0;
	subs = list_prepend_data(subs, sub);
	LOG_INFO(NULL, "Bundle added", class_subscription, "%s", component);
}
