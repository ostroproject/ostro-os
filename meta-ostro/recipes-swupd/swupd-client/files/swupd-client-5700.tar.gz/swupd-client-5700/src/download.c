/*
 *   Software Updater - client side
 *
 *      Copyright © 2012-2015 Intel Corporation.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, version 2 or later of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Authors:
 *         Arjan van de Ven <arjan@linux.intel.com>
 *         Tim Pepper <timothy.c.pepper@linux.intel.com>
 *
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <linux/fs.h>
#include <curl/curl.h>
#include <pthread.h>

#include "config.h"
#include "swupd-build-variant.h"
#include <swupd.h>
#include <swupd_bsdiff.h>

/* This file provides a managed download facility for code that needs a set of
 * update tar files.  Such code starts with one call to "start_full_download()",
 * then makes a series of calls to "full_download()" once per desired file, and
 * then finishes with one call to "end_full_downlad()" which will block until
 * the previously queued downloads are completed and and untarred.
 */

static CURLM *mcurl = NULL;

/*
 * The following represents a hash data structure used inside download.c
 * to track file downloads asynchonously via libcurl.  In the past a
 * single linked list was used, but we may have a very large number of
 * files and repeatedly scan the list could become expensive.  The hashmap
 * gives info on what HASH.tar files will be downloaded.  A de-duplicated
 * set of files is downloaded.  The downloads must complete prior to
 * traversing a manifest, doing hash comparisons, and (re)staging any files
 * whose hash miscompares.
 *
 * file->hash[0] acts as index into the arrays
 */
struct swupd_curl_hashbucket {
	pthread_mutex_t mutex;
	struct list *list;
};
#define SWUPD_CURL_HASH_BUCKETS 256
static struct swupd_curl_hashbucket swupd_curl_hashmap[SWUPD_CURL_HASH_BUCKETS];

/* try to insert the file into the hashmap download queue
 * returns 1 if no download is needed
 * returns 0 if download is needed
 * returns -1 if error */
static int swupd_curl_hashmap_insert(struct file *file) {
	struct list *iter;
	struct file *tmp;
	char *tar_dotfile;
	char *targetfile;
	struct stat stat;
	int hashmap_index = file->hash[0];
	struct swupd_curl_hashbucket *bucket = &swupd_curl_hashmap[hashmap_index];

	pthread_mutex_lock(&bucket->mutex);

	iter = bucket->list;
	while (iter) {
		tmp = iter->data;
		if (hash_compare(tmp->hash, file->hash)) {
			// hash already in download queue
			pthread_mutex_unlock(&bucket->mutex);
			return 1;
		}
		iter = iter->next;
	}

	// if valid target file is already here, no need to download
	string_or_die(&targetfile, "%s/staged/%s", STATE_DIR, file->hash);

	if (lstat(targetfile, &stat) == 0) {
		if (verify_file(file, targetfile)) {
			free(targetfile);
			pthread_mutex_unlock(&bucket->mutex);
			return 1;
		}
	}
	free(targetfile);

	// hash not in queue and not present in staged

	// clean up in case any prior download failed in a partial state
	string_or_die(&tar_dotfile, "%s/download/.%s.tar", STATE_DIR, file->hash);
	unlink(tar_dotfile);
	free(tar_dotfile);

	// queue the hash for download
	iter = bucket->list;
	if ((iter = list_prepend_data(iter, file)) == NULL) {
		LOG_ERROR(file, "swupd_curl_hashmap_insert failed", class_curl, "");
		pthread_mutex_unlock(&bucket->mutex);
		return -1;
	}
	bucket->list = iter;

	pthread_mutex_unlock(&bucket->mutex);
	return 0;
}

/* hysteresis thresholds */
static int MAX_XFER = 25;
static int MAX_XFER_BOTTOM = 15;

int start_full_download(bool pipelining)
{
	int i;

	for (i = 0; i < SWUPD_CURL_HASH_BUCKETS; i++) {
		pthread_mutex_init(&swupd_curl_hashmap[i].mutex, NULL);
	}

	mcurl = curl_multi_init();
	if (mcurl == NULL) {
		LOG_ERROR(NULL, "curl_multi_init failed", class_curl, "");
		return -1;
	}

	/*
	 * we want to not do HTTP pipelining once things have failed once.. in case some transpoxy in the middle
	 * is even more broken than average. This at least will allow the user to update, albeit slowly.
	 */
	if (pipelining) {
		if (curl_multi_setopt(mcurl, CURLMOPT_PIPELINING, 1) != CURLM_OK) {
			LOG_WARN(NULL, "Could not set CURLMOPT_PIPELINING", class_curl, "");
		}
	} else {
		/* survival: don't go too parallel in verify/fix loop */
		MAX_XFER = 1;
		MAX_XFER_BOTTOM = 1;
	}

	return 0;
}

static void free_curl_list_data(void *data)
{
	struct file *file = (struct file*)data;
	CURL *curl = file->curl;

	curl_multi_remove_handle(mcurl, curl);
	curl_easy_cleanup(curl);
}

static void clean_curl_multi_queue(void)
{
	int i;
	struct swupd_curl_hashbucket* bucket;

	for (i = 0; i < SWUPD_CURL_HASH_BUCKETS; i++) {
		bucket = &swupd_curl_hashmap[i];
		pthread_mutex_lock(&bucket->mutex);
		list_free_list_and_data(bucket->list, free_curl_list_data);
		bucket->list = NULL;
		pthread_mutex_unlock(&bucket->mutex);
	}
}

/* list the tarfile content, and verify it contains only one line equal to the expected hash.
 * loop through all the content to detect the case where archive contains more than one file.
 */
static int check_tarfile_content(struct file *file, const char *tarfilename)
{
	int err;
	char *tarcommand;
	FILE *tar;
	int count = 0;

	/* we're using -a because the server side has a choice between different compression methods */
	string_or_die(&tarcommand, "tar -tf %s/download/%s.tar 2> /dev/null", STATE_DIR, file->hash);

	err = access(tarfilename, R_OK);
	if (err) {
		LOG_ERROR(file, "Cannot access tarfilename", class_file_io,
			"\\*tar_filename=\"%s\",strerror=\"%s\"*\\", tarfilename, strerror(errno));
		goto free_tarcommand;
	}

	tar = popen(tarcommand, "r");
	if (tar == NULL) {
		LOG_ERROR(file, "Cannot popen tarcommand", class_file_io,
			"\\*tar_command=\"%s\",strerror=\"%s\"*\\", tarcommand, strerror(errno));
		err = -1;
		goto free_tarcommand;
	}

	while (!feof(tar)) {
		char *c;
		char buffer[PATH_MAXLEN];

		if (fgets(buffer, PATH_MAXLEN, tar) == NULL) {
			if (count != 1) {
				err = -1;
			}
			break;
		}

		c = strchr(buffer, '\n');
		if (c) {
			*c  = 0;
		}
		if (c && (c != buffer) && (*(c-1)=='/')) {
			/* strip trailing '/' from directory tar */
			*(c-1) = 0;
		}
		if (strcmp(buffer, file->hash) != 0) {
			LOG_WARN(file, "Malicious tar file downloaded", class_security,
					"\\*filename=\"%s\",hash=\"%s\",buffer=\"%s\"*\\",
					file->filename, file->hash, buffer);
			err = -1;
			break;
		}
		count++;
	}

	pclose(tar);
free_tarcommand:
	free(tarcommand);

	return err;
}

/* This function will break if the same HASH.tar full file is downloaded
 * multiple times in parallel. */
static void untar_full_download(void *data)
{
	struct file *file = data;
	char *tarfile;
	char *tar_dotfile;
	char *targetfile;
	struct stat stat;
	int err;
	char *tarcommand;

	string_or_die(&tar_dotfile, "%s/download/.%s.tar", STATE_DIR, file->hash);
	string_or_die(&tarfile, "%s/download/%s.tar", STATE_DIR, file->hash);
	string_or_die(&targetfile, "%s/staged/%s", STATE_DIR, file->hash);

	/* If valid target file already exists, we're done.
	 * NOTE: this should NEVER happen given the checking that happens
	 *       ahead of queueing a download.  But... */
	if (lstat(targetfile, &stat) == 0) {
		if (verify_file(file, targetfile)) {
			LOG_ERROR(file, "impossible download race", class_file_io, "");
			unlink(tar_dotfile);
			unlink(tarfile);
			free(tar_dotfile);
			free(tarfile);
			free(targetfile);
			return;
		} else {
			unlink(tarfile);
			unlink(targetfile);
		}
	} else if (lstat(tarfile, &stat) == 0) {
		/* remove tar file from possible past failure */
		LOG_DEBUG(file, "removing pre-existing tar download", class_file_io, "");
		unlink(tarfile);
	}

	err = rename(tar_dotfile, tarfile);
	if (err) {
		LOG_ERROR(file, "Cannot rename tarfile", class_file_io, "\\*tar_filename_dot=\"%s\",strerror=\"%s\"*\\",
				tar_dotfile, strerror(errno));
		free(tar_dotfile);
		goto exit;
	}
	free(tar_dotfile);

	err = check_tarfile_content(file, tarfile);
	if (err) {
		goto exit;
	}

	/* modern tar will automatically determine the compression type used */
	string_or_die(&tarcommand, "tar -C %s/staged/ " TAR_PERM_ATTR_ARGS " -xf %s 2> /dev/null",
			STATE_DIR, tarfile);

	LOG_DEBUG(file, "Doing tar operation", class_file_compression, "%s", tarcommand);
	err = system(tarcommand);
	if (err) {
		/* FIXME: can we respond meaningfully to tar error codes?
		 * symlink untars may have perm/xattr complaints and non-zero
		 * tar return, but symlink (probably?) untarred ok.
		 *
		 * Also getting complaints on some new regular files?
		 *
		 * Either way we verify the hash later, so on error there,
		 * something could try to recover? */
		LOG_ERROR(file, "Tar command error (ignoring)", class_file_compression,
				"\\*err=\"%i\",tarfile=\"%s\"*\\", err, tarfile);
		log_stdout("ignoring tar \"error\" for %s\n", file->hash);
	}
	free(tarcommand);

	err = lstat(targetfile, &stat);
	if (err) {
		LOG_ERROR(file, "targetfile stat error after untar", class_file_io, "\\*new_file=\"%s\",strerror=\"%s\"*\\",
				targetfile, strerror(errno));
	}

	unlink(tarfile);
exit:
	free(tarfile);
	free(targetfile);
	if (err) {
		unlink_all_staged_content(file);
	}
}

static int perform_curl_io_and_complete(int *left)
{
	CURLMsg *msg;
	long ret;
	CURLMcode curlm_ret;
	CURLcode curl_ret;

	curlm_ret = curl_multi_perform(mcurl, left);
	if (curlm_ret != CURLM_OK) {
		LOG_ERROR(NULL, "perform_curl_io_and_complete failed to curl_multi_perform(1)", class_curl,
				"\\*curlm_ret=\"%d\"*\\", curlm_ret);
		return -1;
	}

	while (true) {
		CURL *handle;
		struct file *file;

		msg = curl_multi_info_read(mcurl, left);
		if (!msg) {
			break;
		}
		if (msg->msg != CURLMSG_DONE) {
			LOG_WARN(NULL, "Unknown CURL MSG", class_curl, "\\*curl_msg=\"%d\"*\\", msg->msg);
			continue;
		}

		handle = msg->easy_handle;
		ret = 404;
		curl_ret = curl_easy_getinfo(handle, CURLINFO_RESPONSE_CODE, &ret);
		if (curl_ret != CURLE_OK) {
			LOG_ERROR(NULL, "get CURLINFO_RESPONSE_CODE failed", class_curl,
				"\\*curl_ret=\"%d\"*\\", curl_ret);
			continue;
		}

		curl_ret = curl_easy_getinfo(handle, CURLINFO_PRIVATE, (char **)&file);
		if (curl_ret != CURLE_OK) {
			LOG_ERROR(NULL, "get CURLINFO_PRIVATE failed", class_curl,
				"\\*curl_ret=\"%d\"*\\", curl_ret);
			curl_easy_cleanup(handle);
			continue;
		}

		if (ret == 200) {
			untar_full_download(file);
		} else {
			char *url = NULL;

			curl_easy_getinfo(handle, CURLINFO_EFFECTIVE_URL, &url);

			LOG_ERROR(file, "http response failure", class_curl,
				"\\*http_code=\"%i\",url=\"%s\"*\\", ret, url);
			unlink_all_staged_content(file);
		}
		if (file->staging) {
			free(file->staging);
			file->staging = NULL;
		}

/* NOTE: Intentionally no removal of file from hashmap.  All needed files
 * need determined and queued in one complete preparation phase.  Once all
 * needed files are all present, they can be staged.  Otherwise a complex
 * datastructure and retries are needed to insure only one download of a file
 * happens fully to success AND a HASH.tar is uncompressed to and HASH and
 * staged to the _multiple_ filenames with that hash. */

		curl_multi_remove_handle(mcurl, handle);
		curl_easy_cleanup(handle);
		file->curl = NULL;
	}

	curlm_ret = curl_multi_perform(mcurl, left);
	if (curlm_ret != CURLM_OK) {
		LOG_ERROR(NULL, "perform_curl_io_and_complete failed to curl_multi_perform(2)", class_curl,
				"\\*curlm_ret=\"%d\"*\\", curlm_ret);
		return -1;
	}

	return 0;
}

/* 2 limits, so that we can have hysteresis in behavior. We let the caller
 * add new transfer up until the queue reaches the high threshold. At this point
 * we don't return to the caller and instead process the queue until its len
 * gets below the low threshold */
static int poll_fewer_than(int xfer_queue_high, int xfer_queue_low)
{
	int left;
	CURLMcode curlm_ret;

	curlm_ret = curl_multi_perform(mcurl, &left);
	if (curlm_ret != CURLM_OK) {
		LOG_ERROR(NULL, "poll fewer than failed to curl_multi_perform()", class_curl,
				"\\*curlm_ret=\"%d\"*\\", curlm_ret);
		return -1;
	}

	if (left <= xfer_queue_high) {
		return 0;
	}

	while (left > xfer_queue_low) {
		usleep(500); /* TODO this really ought to be a select() statement */
		if (perform_curl_io_and_complete(&left) != 0)
			return -1;
	}

	return 0;
}

/* full_download() attempts to enqueue a file for later asynchronous download  */
int full_download(struct file *file)
{
	char *url = NULL;
	CURL *curl = NULL;
	int ret = -EFULLDOWNLOAD;
	char *filename = NULL;
	CURLMcode curlm_ret = CURLM_OK;
	CURLcode curl_ret = CURLE_OK;

	ret = swupd_curl_hashmap_insert(file);
	if (ret > 0) {		/* no download needed */
		goto out_good;
	} else if (ret < 0) {	/* error */
		goto out_bad;
	} /* else (ret == 0)	   download needed */

	curl = curl_easy_init();
	if (curl == NULL) {
		LOG_ERROR(file, "full_download failed to curl_easy_init()", class_curl, "");
		goto out_bad;
	}
	file->curl = curl;

	ret = poll_fewer_than(MAX_XFER, MAX_XFER_BOTTOM);
	if (ret) {
		clean_curl_multi_queue();
		goto out_bad;
	}

	string_or_die(&url, "%s/%i/files/%s.tar", preferred_content_url, file->last_change, file->hash);

	string_or_die(&filename, "%s/download/.%s.tar", STATE_DIR, file->hash);
	file->staging = filename;

	curl_ret = curl_easy_setopt(curl, CURLOPT_PRIVATE, (void*)file);
	if (curl_ret != CURLE_OK)
		goto out_bad;
	curl_ret = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, swupd_download_file);
	if (curl_ret != CURLE_OK)
		goto out_bad;
	curl_ret = curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)file);
	if (curl_ret != CURLE_OK)
		goto out_bad;

	curl_ret = swupd_curl_set_basic_options(curl, url);
	if (curl_ret != CURLE_OK)
		goto out_bad;

	curlm_ret = curl_multi_add_handle(mcurl, curl);
	if (curlm_ret != CURLM_OK) {
		goto out_bad;
	}

	if (poll_fewer_than(MAX_XFER + 10, MAX_XFER) != 0) {
		clean_curl_multi_queue();
	}
	ret = 0;
	goto out_good;

out_bad:
	if (curlm_ret != CURLM_OK) {
		LOG_ERROR(file, "full_download failed to curl_multi_add_handle()", class_curl,
				"\\*curlm_ret=\"%d\"*\\", curlm_ret);
	}
	if (curl_ret != CURLE_OK) {
		LOG_ERROR(file, "full_download failed to set curl options", class_curl,
				"\\*curl_ret=\"%d\"*\\", curl_ret);
	}
	if (curl) {
		curl_easy_cleanup(curl);
	}
	free(filename);
out_good:
	free(url);
	return ret;
}

void end_full_download(void)
{
	int left;
	int err;
	CURLMcode curlm_ret;

	log_stdout("downloading files, this may take a while\n");

	if (poll_fewer_than(0, 0) == 0) {
		err = perform_curl_io_and_complete(&left);
		if (err) {
			LOG_WARN(NULL, "end_full_download failed to drain the mcurl queue", class_curl, "");
			clean_curl_multi_queue();
		}
	}

	curlm_ret = curl_multi_cleanup(mcurl);
	if (curlm_ret != CURLM_OK) {
		LOG_WARN(NULL, "end_full_download failed to curl_multi_cleanup()", class_curl,
				"\\*curlm_ret=\"%d\"*\\", curlm_ret);
	}
}
