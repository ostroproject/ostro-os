/*
 *   Software Updater - client side
 *
 *      Copyright © 2012-2015 Intel Corporation.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, version 2 or later of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Authors:
 *         Arjan van de Ven <arjan@linux.intel.com>
 *         Timothy C. Pepper <timothy.c.pepper@linux.intel.com>
 *         Tudor Marcu <tudor.marcu@intel.com>
 *
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <sys/stat.h>

#include <swupd.h>

static void update_kernel(void)
{
	int ret;
	char *kernel_update_cmd = NULL;
	LOG_INFO(NULL, "calling kernel helper", class_scripts, "");

	if (strcmp("/", path_prefix) == 0) {
		string_or_die(&kernel_update_cmd, "/usr/bin/kernel_updater.sh");
	} else {
		string_or_die(&kernel_update_cmd, "%s/usr/bin/kernel_updater.sh --path %s", path_prefix, path_prefix);
	}

	ret = system(kernel_update_cmd);
	if (ret != 0)
		LOG_ERROR(NULL, "kernel_update failed", class_scripts, "%d", ret);
	free(kernel_update_cmd);
}

static void update_bootloader(void)
{
	int ret;
	char *bootloader_update_cmd = NULL;
	LOG_INFO(NULL, "calling bootloader helper", class_scripts, "");

	if (strcmp("/", path_prefix) == 0) {
		string_or_die(&bootloader_update_cmd, "/usr/bin/gummiboot_updaters.sh");
	} else {
		string_or_die(&bootloader_update_cmd, "%s/usr/bin/gummiboot_updaters.sh --path %s", path_prefix, path_prefix);
	}

	ret = system(bootloader_update_cmd);
	if (ret != 0)
		LOG_ERROR(NULL, "gummiboot_updaters failed", class_scripts, "%d", ret);
	free(bootloader_update_cmd);

	if (strcmp("/", path_prefix) == 0) {
		string_or_die(&bootloader_update_cmd, "/usr/bin/systemdboot_updater.sh");
	} else {
		string_or_die(&bootloader_update_cmd, "%s/usr/bin/systemdboot_updater.sh --path %s", path_prefix, path_prefix);
	}

	ret = system(bootloader_update_cmd);
	if (ret != 0)
		LOG_ERROR(NULL, "systemdboot_updater failed", class_scripts, "%d", ret);
	free(bootloader_update_cmd);
}

static void update_triggers(void)
{
	int ret;
	LOG_INFO(NULL, "calling systemd trigger", class_scripts, "");

	ret = system("/usr/bin/systemctl daemon-reload");
	if (ret != 0)
		LOG_ERROR(NULL, "systemd daemon reload failed", class_scripts, "%d", ret);
	ret = system("/usr/bin/systemctl restart update-triggers.target");
	if (ret != 0)
		LOG_ERROR(NULL, "systemd update triggers failed", class_scripts, "%d", ret);
}

void run_scripts(void)
{
	progress_step(PROGRESS_MSG_HELPER_SCRIPTS);
	LOG_INFO(NULL, "calling update helpers", class_scripts, "");

	/* path_prefix aware helper */
	if (need_update_boot) {
		LOG_INFO(NULL, "need_update_boot", class_scripts, "true");
		update_kernel();
	} else {
		log_stdout("No kernel update needed, skipping helper call out.\n");
		LOG_INFO(NULL, "need_update_boot", class_scripts, "false");
	}

	if (need_update_bootloader) {
		LOG_INFO(NULL, "need_update_bootloader", class_scripts, "true");
		update_bootloader();
	} else {
		log_stdout("No bootloader update needed, skipping helper call out.\n");
		LOG_INFO(NULL, "need_update_bootloader", class_scripts, "false");
	}

	/* helpers which don't run when path_prefix is set */
	if (strcmp("/", path_prefix) != 0) {
		LOG_DEBUG(NULL, "skipping non-path_prefix-aware helpers", class_scripts, "");
		return;
	}

	/* Crudely call post-update hooks after every update, must fix with proper conditions and log output */
	update_triggers();
}

/* Run any "mandatory" pre-update scripts needed. In this case, mandatory
 * means the script must run, but it is not yet fatal if the script does not
 * return success */
void run_preupdate_scripts(struct manifest *manifest)
{
	struct list *iter = list_tail(manifest->files);
	struct file *file;
	struct stat sb;
	char *script;
	int ret = -1;

	LOG_INFO(NULL, "Searching for preupdate helper", class_scripts, "");

	string_or_die(&script, "/usr/bin/clr_pre_update.sh");

	if (stat(script, &sb) == -1) {
		LOG_DEBUG(NULL, "No clr_pre_update script to run on system\n", class_scripts, "");
		free(script);
		return;
	}

	while (iter != NULL) {
		file = iter->data;
		iter = iter->prev;

		if (strcmp(file->filename, script) != 0) {
			continue;
		}

		/* Check that system file matches file in manifest */
		if (verify_file(file, script)) {
			LOG_INFO(NULL, "calling preupdate helper", class_scripts, "");
			ret = system(script);
			break;
		}
	}

	if (ret != 0)
		LOG_ERROR(NULL, "Failed to run preupdate script", class_scripts, " %s\n", script);
	free(script);
}
