/*
 *   Software Updater - client side
 *
 *      Copyright © 2012-2015 Intel Corporation.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, version 2 or later of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Authors:
 *         Arjan van de Ven <arjan@linux.intel.com>
 *         Tim Pepper <timothy.c.pepper@linux.intel.com>
 *
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "config.h"
#include <swupd.h>
#include "progress.h"

/* this function attempts to download the latest server version string file from
 * the preferred server to a memory buffer, returning either a negative integer
 * error code or >= 0 representing the server version */
static int try_version_download(void)
{
	char *url = NULL;
	char *path = NULL;
	int ret = 0;
	char *tmp_version;

	tmp_version = malloc(LINE_MAX);
	if (tmp_version == NULL) {
		abort();
	}

	string_or_die(&url, "%s/version/format%s/latest", preferred_version_url, format_string);

	string_or_die(&path, "%s/server_version", STATE_DIR);

	unlink(path);

	ret = swupd_curl_get_file(url, path, NULL, tmp_version, false);
	if (ret) {
		LOG_DEBUG(NULL, "Getting server version failed", class_curl,
				"\\*ret=\"%d\",url=\"%s\"*\\", ret, url);
		goto out;
	} else {
		ret = strtol(tmp_version, NULL, 10);
		LOG_DEBUG(NULL, "Got server version", class_curl,
				"\\*ret=\"%d\"*\\", ret);
	}

out:
	free(path);
	free(url);
	free(tmp_version);
	return ret;
}

bool check_network(void)
{
	int ret;

	if (!have_network) {
		ret = try_version_download();
		if (ret < 0) {
			LOG_DEBUG(NULL, "no network", class_network, "");
			have_network = false;
		} else {
			LOG_DEBUG(NULL, "have network", class_network, "");
			have_network = true;
		}
	}

	return have_network;
}

int read_version_from_subvol_file(char *path_prefix)
{
	char line[LINE_MAX];
	FILE *file;
	int v = -1;
	char *buildstamp;

	string_or_die(&buildstamp, "%s/usr/lib/os-release", path_prefix);
	file = fopen(buildstamp, "rm");
	if (!file) {
		LOG_ERROR(NULL, "Cannot read os-release from /usr/lib", class_file_io, "\\*buildstamp=\"%s\",strerror=\"%s\"*\\",
				buildstamp, strerror(errno));
		string_or_die(&buildstamp, "%s/etc/os-release", path_prefix);
		file = fopen(buildstamp, "rm");
		if (!file) {
			LOG_ERROR(NULL, "Cannot read os-release /etc", class_file_io, "\\*buildstamp=\"%s\",strerror=\"%s\"*\\",
					buildstamp, strerror(errno));
			free(buildstamp);
			return v;
		}
	}

	while(!feof(file)) {
		line[0] = 0;
		if (fgets(line, LINE_MAX, file) == NULL)
			break;

		if (strncmp(line,"VERSION_ID=", 11) == 0) {
			v = strtoull(&line[11], NULL, 10);
			break;
		}
	}

	free(buildstamp);
	fclose(file);
	return v;
}

#ifdef SWUPD_WITH_BTRFS
static int read_version_from_swupd_file(char *filename)
{
	FILE *file;
	int v = -1;
	char *fullfile = NULL;

	string_or_die(&fullfile, "%s/%s", STATE_DIR, filename);

	file = fopen(fullfile, "rm");

	if (!file) {
		LOG_ERROR(NULL, "Cannot read version file", class_file_io, "\\*fullfile=\"%s\",strerror=\"%s\"*\\",
				fullfile, strerror(errno));
		free(fullfile);
		return v;
	}

	if (fscanf(file, "%i", &v) < 0)
		LOG_ERROR(NULL, "version file empty", class_file_misc, "\\*fullfile=\"%s\"*\\", fullfile);

	fclose(file);
	free(fullfile);

	return v;
}
#endif

void read_versions(int *current_version, int *latest_version, int *server_version)
{

#ifdef SWUPD_WITH_BTRFS
#warning btrfs version handling needs fixing after zero version fixes
	*current_version = read_version_from_subvol_file("");
	*latest_version = read_version_from_swupd_file("version");
	if (*latest_version == -1)
		*latest_version = read_version_from_subvol_file(STAGING_SUBVOL);
	if (*current_version <= 0 || *latest_version <= 0) {
		LOG_ERROR(NULL, "Invalid version numbers", class_version, "\\*current_version=\"%d\",latest_version=\"%d\"*\\",
				*current_version, *latest_version);
	}
#else	/*SWUPD_WITHOUT_BTRFS*/
	*current_version = *latest_version = read_version_from_subvol_file("");
	if (*latest_version < 0) {
		LOG_ERROR(NULL, "Invalid version number", class_version, "\\*latest_version=\"%d\"*\\",
				*latest_version);
		return;
	}
#endif

	progress_step(PROGRESS_MSG_GET_SERVER_VERSION);
	LOG_INFO(NULL, "Getting version from server", class_version, "");
	*server_version = try_version_download();
	if (*server_version < 0) {
		LOG_ERROR(NULL, "Invalid Server version number", class_version,
				"\\*server_version=\"%d\"*\\", *server_version);
	}
}

int check_versions(int *current_version, int *latest_version, int *server_version)
{

	read_versions(current_version, latest_version, server_version);

	if (*latest_version < 0) {
		return -1;
	}
	if (*latest_version == 0) {
		LOG_ERROR(NULL, "Update from version 0 not supported yet", class_version, "");
		log_stdout("Update from version 0 not supported yet.\n");
		return -1;
	}
	if (SWUPD_VERSION_IS_DEVEL(*current_version) || SWUPD_VERSION_IS_RESVD(*current_version)) {
		LOG_ERROR(NULL, "Update of dev build not supported", class_version,
				"\\*current_version=\"%d\"*\\", *current_version);
		log_stdout("Update of dev build not supported %d\n", *current_version);
		return -1;
	}
	swupd_curl_set_current_version(*latest_version);

	/* set preferred version and content server urls */
	if (*server_version < 0) {
		have_network = false;
		return -1;
	}

	have_network = true;

	//TODO allow policy layer to send us to intermediate version?

	swupd_curl_set_requested_version(*server_version);

	return 0;
}

int update_device_latest_version(int version)
{
	FILE *file = NULL;
	char *path = NULL;

	string_or_die(&path, "%s/version", STATE_DIR);
	file = fopen(path, "w");
	if (!file) {
		LOG_ERROR(NULL, "Cannot open version file for write", class_version, "");
		free(path);
		return -1;
	}

	fprintf(file, "%i\n", version);
	fflush(file);
	fdatasync(fileno(file));
	fclose(file);
	free(path);
	return 0;
}
