/*
 *   Software Updater - client side
 *
 *      Copyright © 2013-2015 Intel Corporation.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, version 2 or later of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Authors:
 *         Regis Merlino <regis.merlino@intel.com>
 *         Sebastien Boeuf <sebastien.boeuf@intel.com>
 *         Jaime A. Garcia <jaime.garcia.naranjo@intel.com>
 *
 */

#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdint.h>

#include "config.h"
#include "log-internal.h"
#include <swupd.h>

#ifdef SWUPD_WITH_TELEMETRY
#include <stdarg.h>
#include <dlfcn.h>
#include <string.h>

static uint32_t priority_to_tm(enum log_priority priority)
{
	uint32_t severity;

	/*
	 * Telemetry severity range is ordered in this way:
	 * 4 - highest severity -> ERROR
	 * 3 - ...		-> WARNING
	 * 2 - ...		-> DEBUG
	 * 1 - Lowest severity	-> INFO
	 */
	switch (priority) {
	case log_info:
		severity = 1;
		break;
	case log_debug:
		severity = 2;
		break;
	case log_warning:
		severity = 3;
		break;
	case log_error:
		severity = 4;
		break;
	default:
		abort();
	}

	return severity;
}

int _tm_send_record(enum log_priority priority, char *classification, char *payload, size_t UNUSED_PARAM len)
{
	uint32_t version = 1;
	int ret = 0;
	tmref tm_rec = NULL;

	if (!has_telemetry)
		return EXIT_FAILURE;

	(*tm_create_record)(&tm_rec, priority_to_tm(priority), classification, version);
	(*tm_set_payload)(tm_rec, payload);
	if ((ret = (*tm_send_record)(tm_rec)) < 0) {
		return EXIT_FAILURE;
	}

	/* Free record's memory */
	(*tm_free_record)(tm_rec);

	return EXIT_SUCCESS;
}

#if 0
int __tm_send_record(enum log_priority priority, char *msg, enum log_class_msg class_msg,
			char *filename, int linenr, const char *fmt, ...)
{
	char *buf;
	char *classification = NULL;
	int ret;
	va_list ap;

	if (!has_telemetry)
		return EXIT_FAILURE;

	va_start(ap, fmt);
	buf = format_log_message(TM_TYPE, priority, NULL, msg, filename, linenr, fmt, ap);

	classification = format_classification_message(class_msg);

	ret = _tm_send_record(priority, classification, buf, strlen(buf));

	va_end(ap);
	free(classification);

	free(buf);

	return ret;
}
#endif
#endif
