/*
 *   Software Updater - client side
 *
 *      Copyright (c) 2012-2015 Intel Corporation.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, version 2 or later of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Authors:
 *         Arjan van de Ven <arjan@linux.intel.com>
 *         Tim Pepper <timothy.c.pepper@linux.intel.com>
 *         Jaime A. Garcia <jaime.garcia.naranjo@linux.intel.com>
 *
 */

#define _GNU_SOURCE
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <libgen.h>
#include <getopt.h>

#include <swupd.h>

#define MODE_RW_O (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)
#define VERIFY_NOPICKY 0

bool list = false;
static char **bundles;

static void print_help(const char *name) {
	printf("Usage:\n");
	printf("   swupd %s [options] [bundle1 bundle2 (...)]\n\n", basename((char*)name));
	printf("Help Options:\n");
	printf("   -h, --help              Show help options\n");
	printf("   -u, --url=[URL]         RFC-3986 encoded url for version string and content file downloads\n");
	printf("   -p, --path=[PATH...]    Use [PATH...] as the path to verify (eg: a chroot or btrfs subvol\n");
	printf("   -F, --format=[staging,1,2,etc.]  the format suffix for version file downloads\n");
	printf("   -l, --list              List all available bundles for the current version of Clear Linux\n");
	printf("   -V, --verbose           Increase verbosity of log and console messages\n");
	printf("   -L, --log=[level]       Enable log level [error|warn|debug|info]. Default log level is error\n");
	printf("   -q, --quiet             Silent run, do not print any ouput to the screen\n");
	printf("\n");
}

static const struct option prog_opts[] = {
	{"help", no_argument, 0, 'h'},
	{"verbose", no_argument, 0, 'V'},
	{"url", required_argument, 0, 'u'},
	{"list", no_argument, 0, 'l'},
	{"path", required_argument, 0, 'p'},
	{"format", required_argument, 0, 'F'},
	{"log", required_argument, 0, 'L'},
	{"quiet", no_argument, 0, 'q'},
	{0, 0, 0, 0}
};

static bool parse_options(int argc, char **argv)
{
	int opt;

	set_format_string(NULL);

	while ((opt = getopt_long(argc, argv, "hu:p:F:lVL:q", prog_opts, NULL)) != -1) {
		switch (opt) {
		case '?':
		case 'h':
			print_help(argv[0]);
			return false;
		case 'u':
			if (!optarg) {
				printf("error: invalid --url argument\n\n");
				goto err;
			}
			if (version_server_urls[0])
				free(version_server_urls[0]);
			if (content_server_urls[0])
				free(content_server_urls[0]);
			string_or_die(&version_server_urls[0], "%s", optarg);
			string_or_die(&content_server_urls[0], "%s", optarg);
			break;
		case 'p': /* default empty path_prefix verifies the running OS */
			if (!optarg) {
				printf("Invalid --path argument\n\n");
				goto err;
			}
			if (path_prefix) /* multiple -p options */
				free(path_prefix);
			string_or_die(&path_prefix, "%s", optarg);
			break;
		case 'F':
			if (!optarg || !set_format_string(optarg)) {
				printf("Invalid --format argument\n\n");
				goto err;
			}
			break;
		case 'V':
			verbose++;
			break;
		case 'l':
			list = true;
			break;
		case 'L':
			if (!optarg || !set_log_level(optarg)) {
				printf("Invalid --log argument\n\n");
				goto err;
			}
			break;
		case 'q':
			verbose = -1;
			break;
		default:
			printf("error: unrecognized option\n\n");
			goto err;
		}
	}

	if (!list) {
		if (argc <= optind) {
			printf("error: missing bundle(s) to be installed\n\n");
			goto err;
		}

		bundles = argv + optind;
	}

	return true;
err:
	print_help(argv[0]);
	return false;
}

int bundle_add_main(int argc, char **argv)
{
	copyright_header("bundle adder");

	if (!parse_options(argc, argv))
		return EXIT_FAILURE;

	if (list) {
		return list_installable_bundles();
	} else {
		return install_bundles(bundles);
	}
}
