/*
 *   Software Updater - client side
 *
 *      Copyright © 2012-2015 Intel Corporation.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, version 2 or later of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Authors:
 *         Arjan van de Ven <arjan@linux.intel.com>
 *         Tim Pepper <timothy.c.pepper@linux.intel.com>
 *
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "config.h"
#include "swupd-build-variant.h"
#include <swupd.h>
#include "progress.h"
#include <signature.h>


static int download_pack(int oldversion, int newversion, char *module)
{
	FILE *tarfile = NULL;
	char *tar = NULL;
	char *url = NULL;
	int err = -1;
	char *filename;
	struct stat stat;

	string_or_die(&filename, "%s/pack-%s-from-%i-to-%i.tar", STATE_DIR, module, oldversion, newversion);

	err = lstat(filename, &stat);
	if (err == 0 && stat.st_size == 0) {
		LOG_DEBUG(NULL, "Downloading pack", class_curl, "%s was already downloaded/extracted", filename);
		free(filename);
		return 0;
	}

	log_stdout("Downloading %s pack for version %i\n", module, newversion);
	LOG_DEBUG(NULL, "Downloading pack", class_curl, "module %s version %i", module, newversion);

	string_or_die(&url, "%s/%i/pack-%s-from-%i.tar", preferred_content_url, newversion, module, oldversion);

	err = swupd_curl_get_file(url, filename, NULL, NULL, true);
	if (err) {
		LOG_WARN(NULL, "pack download failed", class_curl, "\\*err=\"%d\"*\\", err);
		free(url);
		if ((lstat(filename, &stat) == 0) && (stat.st_size == 0)) {
			unlink(filename);
		}
		free(filename);
		return err;
	}

	if (!signature_download_and_verify(url, filename)) {
		LOG_ERROR(NULL, "manifest delta signature failed", class_security, "\\*file=\"%i/pack-%s-from-%i.tar\"*\\",
			  newversion, module, oldversion);
		free(url);
		unlink(filename);
		free(filename);
		return -1;
	}

	free(url);

	progress_step(PROGRESS_MSG_EXTRACTING_PACK);
	string_or_die(&tar, "tar -C %s " TAR_PERM_ATTR_ARGS " -xf %s/pack-%s-from-%i-to-%i.tar 2> /dev/null",
			STATE_DIR, STATE_DIR, module, oldversion, newversion);

	LOG_INFO(NULL, "Untar of delta pack", class_file_compression, "%s", tar);
	err = system(tar);
	if (err)
		LOG_INFO(NULL, "Untar of delta pack had errors, probably acceptable symlink permission \"errors\"", class_file_compression, "");
	free(tar);
	unlink(filename);
	/* make a zero sized file to prevent redownload */
	tarfile = fopen(filename, "w");
	free(filename);
	if (tarfile) {
		fclose(tarfile);
	}

	return 0;
}

/* pull in packs for base and any subscription */
int download_subscribed_packs(int oldversion, int UNUSED_PARAM newversion, bool required)
{
	struct list *iter;
	struct sub *sub = NULL;
	int err;

	if (!check_network()) {
		LOG_ERROR(NULL, "Network issue prevents subscribed packs download",
			class_network, "");
		return -ENOSWUPDSERVER;
	}

	LOG_INFO(NULL, "downloading packs", class_subscription, "");
	iter = list_head(subs);
	while (iter) {
		sub = iter->data;
		iter = iter->next;

		if (sub->oldversion == sub->version) // pack didn't change in this release
			continue;

		if (oldversion != 0)
			oldversion = sub->oldversion;

		LOG_DEBUG(NULL, "downloading component pack ", class_subscription,
			"\\*component=\"%s\",oldversion=\"%d\",newversion=\"%d\"*\\",
			sub->component, oldversion, sub->version);
		err = download_pack(oldversion, sub->version, sub->component);
		if (err < 0) {
			LOG_DEBUG(NULL, "downloading pack failed", class_subscription,
				"\\*component=\"%s\",oldversion=\"%d\",newversion=\"%d\"*\\",
				sub->component, oldversion, sub->version);
			if (required) {
				return err;
			} else {
				continue;
			}
		}
	}

	return 0;
}
