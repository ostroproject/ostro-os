/*
 *   Software Updater - client side
 *
 *      Copyright (c) 2012-2015 Intel Corporation.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, version 2 or later of the License.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *   Authors:
 *         Arjan van de Ven <arjan@linux.intel.com>
 *         Tim Pepper <timothy.c.pepper@linux.intel.com>
 *         Jaime A. Garcia <jaime.garcia.naranjo@linux.intel.com>
 *
 */

#define _GNU_SOURCE
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <libgen.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <getopt.h>

#include <swupd.h>

#define VERIFY_PICKY 1

static char *bundle_name = NULL;

static void print_help(const char *name) {
	printf("Usage:\n");
	printf("   swupd %s [options] bundlename\n\n", basename((char*)name));
	printf("Help Options:\n");
	printf("   -h, --help              Show help options\n");
	printf("   -u, --url=[URL]         RFC-3986 encoded url for version string and content file downloads\n");
	printf("   -V, --verbose           Increase verbosity of log and console messages\n");
	printf("   -L, --log=[level]       Enable log level [error|warn|debug|info]. Default log level is error\n");
	printf("   -q, --quiet             Silent run, do not print any ouput to the screen\n");
	printf("\n");
}

static const struct option prog_opts[] = {
	{"help", no_argument, 0, 'h'},
	{"verbose", no_argument, 0, 'V'},
	{"url", required_argument, 0, 'u'},
	{"log", required_argument, 0, 'L'},
	{"quiet", no_argument, 0, 'q'},
	{0, 0, 0, 0}
};

static bool parse_options(int argc, char **argv)
{
	int opt;

	while ((opt = getopt_long(argc, argv, "hu:VL:q", prog_opts, NULL)) != -1) {
		switch (opt) {
		case '?':
		case 'h':
			print_help(argv[0]);
			return false;
		case 'u':
			if (!optarg) {
				printf("error: invalid --url argument\n\n");
				goto err;
			}
			if (version_server_urls[0])
				free(version_server_urls[0]);
			if (content_server_urls[0])
				free(content_server_urls[0]);
			string_or_die(&version_server_urls[0], "%s", optarg);
			string_or_die(&content_server_urls[0], "%s", optarg);
			break;
		case 'V':
			verbose++;
			break;
		case 'L':
			if (!optarg || !set_log_level(optarg)) {
				printf("Invalid --log argument\n\n");
				goto err;
			}
			break;
		case 'q':
			verbose = -1;
			break;
		default:
			printf("error: unrecognized option\n\n");
			goto err;
		}
	}

	if (argc == optind) {
		printf("error: bundle name missing\n\n");
		goto err;
	}
	string_or_die(&bundle_name, "%s", argv[optind]);

	return true;
err:
	print_help(argv[0]);
	return false;

}

int bundle_remove_main(int argc, char **argv)
{
	int ret;

	copyright_header("bundle remover");

	if (!parse_options(argc, argv))
		return EINVALID_OPTION;

	ret = remove_bundle(bundle_name);
	free(bundle_name);

	return ret;
}
