#ifndef __INCLUDE_GUARD_SWUPD_BUILD_VARIANT_H
#define __INCLUDE_GUARD_SWUPD_BUILD_VARIANT_H

#include <dirent.h>
#include <stdbool.h>

#include "config.h"
#include "list.h"
#include "swupd.h"

#ifdef SWUPD_WITH_BTRFS
#define BTRFS_SLEEP_TIME 20                             /* 20 seconds */
#define VERIFY_FAILED_MAX_VERSIONS_COUNT 20
#endif

#ifdef SWUPD_WITH_SELINUX
#define TAR_PERM_ATTR_ARGS "--preserve-permissions --xattrs --xattrs-include='*' --selinux"
#else /* SWUPD_WITHOUT_SELINUX */
#define TAR_PERM_ATTR_ARGS "--preserve-permissions --xattrs --xattrs-include='*'"
#endif

#ifdef SWUPD_WITH_REPAIR
enum repair_reason {
	repair_boot_check_failure,
	repair_verify_failure,
	repair_update_failure,
	repair_restore_starpeak
};
#endif

#ifdef SWUPD_WITH_ESP
extern int efivar_bootloader_boot_check(int version, bool repair_fallback);
extern int efivar_bootloader_set_next_boot_to_version(int version);
extern int efivar_bootloader_set_next_boot_to_repair(enum repair_reason reason, struct list *version_list);
typedef void (*efivar_bootloader_boot_for_repair_needed_cb_t)(void);
extern void efivar_bootloader_set_boot_for_repair_needed_cb(efivar_bootloader_boot_for_repair_needed_cb_t);
extern int efivar_bootloader_clear_verify_error(void);
extern void efivar_bootloader_dump(void);

extern void critical_verify_multi_error(struct list *version_list);
extern void fatal_update_error(int from_version, int to_version);
#endif /* SWUPD_*_ESP */

#ifdef SWUPD_WITH_ESP
#define ESP_OS_MIN_FREE_SIZE (1024 * 1024 * 120)	/* 120M */
#endif

#ifdef SWUPD_WITH_REPAIROS
#define MAX_REPAIR_OS_TO_KEEP 2 /* plus 1 about to be installed */
#endif

#ifdef SWUPD_WITH_BTRFS
#define MAX_OS_TO_KEEP 4	/* plus 1 about to be installed */
#endif

#ifdef SWUPD_WITH_BTRFS
extern int remove_snapshot(const char *version);
extern int snapshotsort(const struct dirent **first, const struct dirent **second);
typedef int (*dirent_cmp_fn_t)(const struct dirent **first, const struct dirent **second);
extern char *get_snapshot_list(int current, int latest, dirent_cmp_fn_t dirent_cmp_fn, int *num_elements);
#endif

#endif
