#ifndef __INCLUDE_GUARD_LOG_INTERNAL_H
#define __INCLUDE_GUARD_LOG_INTERNAL_H

#include <stdbool.h>
#include <stdint.h> // for uint32_t

#include "config.h"
#include "log.h"

#ifdef SWUPD_WITH_TELEMETRY
#define TELEMETRY_LIBRARY "/usr/lib64/libtelemetry.so.3"

#if 0
int __tm_send_record(enum log_priority priority, char *msg, enum log_class_msg class_msg,
			char *filename, int linenr, const char *fmt, ...);
#endif
int _tm_send_record(enum log_priority priority, char *classification, char *payload, size_t len);
typedef struct telem_ref *tmref;
extern int (*tm_create_record)(struct telem_ref **, uint32_t, char *, uint32_t);
extern int (*tm_set_payload)(tmref, char *);
extern int (*tm_send_record)(tmref);
extern void (*tm_free_record)(tmref);

#define TM_SEND_RECORD(priority, msg, class_msg, fmt...) __tm_send_record(priority, msg, class_msg, __FILE__, __LINE__, fmt)
#else
#define TM_SEND_RECORD(priority, msg, class_msg, fmt...)
#endif

#endif
