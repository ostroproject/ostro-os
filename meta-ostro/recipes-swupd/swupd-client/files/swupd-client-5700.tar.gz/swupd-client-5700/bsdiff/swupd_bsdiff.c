/*-
 * Copyright 2003-2005 Colin Percival
 * All rights reserved
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted providing that the following conditions 
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#if 0
__FBSDID
    ("$FreeBSD: src/usr.bin/bsdiff/bsdiff/bsdiff.c,v 1.1 2005/08/06 01:59:05 cperciva Exp $");
#endif

/*
 * REMINDER: modifications here need to find their way to both client and
 * server.  The client does not have a hard requirement on bsdiff.c, but for
 * client side testing it is useful to have in addition to bspatch.c.
 */

#define _GNU_SOURCE
#include "config.h"
#include "swupd.h"

#include <sys/types.h>
#ifdef SWUPD_WITH_BZIP2
#include <bzlib.h>
#endif
#include <err.h>
#include <fcntl.h>
#include <lzma.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <zlib.h>
#include <endian.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <pthread.h>
#include <assert.h>
#include <sys/mman.h>

#include "swupd_bsdiff.h"
#include "xattrs.h"

static int bsdiff_files;
static uint64_t bsdiff_newbytes;
static uint64_t bsdiff_outputbytes;
static int bsdiff_gzip;
static int bsdiff_bzip2;
static int bsdiff_xz;
static int bsdiff_none;
static int bsdiff_zeros;
static int bsdiff_fulldl;

static char *algos[BSDIFF_ENC_LAST] = {"invalid", "none ", "bzip2", "gzip ", "xz   ", "zeros"};

#if 0
static void bsdiff_log_stats(void)
{
	LOG_INFO(NULL, "bsdiff delta results", class_stats, "");
	LOG_INFO(NULL, "File count", class_stats, "%i", bsdiff_files);
	LOG_INFO(NULL, "FULLDL count", class_stats, "%i", bsdiff_fulldl);
	LOG_INFO(NULL, "Original size  :", class_stats, "%5.2f Mb", bsdiff_newbytes / 1024 / 1024.0);
	LOG_INFO(NULL, "Delta size     :", class_stats, "%5.2f Mb", bsdiff_outputbytes / 1024 / 1024.0);
	LOG_INFO(NULL, "Ratio          :", class_stats, "%5.2f", bsdiff_newbytes / (bsdiff_outputbytes+1.0));
	LOG_INFO(NULL, "Compression algorithms", class_stats,"");
	LOG_INFO(NULL, "  none         : ", class_stats, "%i", bsdiff_none);
	LOG_INFO(NULL, "  gzip         : ", class_stats, "%i", bsdiff_gzip);
	LOG_INFO(NULL, "  bzip2        : ", class_stats, "%i", bsdiff_bzip2);
	LOG_INFO(NULL, "  xz           : ", class_stats, "%i", bsdiff_xz);
	LOG_INFO(NULL, "  zeros        : ", class_stats, "%i", bsdiff_zeros);
}
#endif

/* TODO: oh dear, another MIN that multiple evaluates....  */
#undef MIN
#define MIN(x,y) (((x)<(y)) ? (x) : (y))

/* NOTES:
 * I and V are chunks of memory (arrays) with length = (oldfile size +1) * sizeof(int64_t).
 * Additionally, we pass in arraylen now. The parent function qsufsort receives it, so it
 * should be available here as well for error checking.
 * start: is actually the point in the array sent in during the suffix sort, which sorts by
 * small blocks/chunks.
 * len: refers to the length of the current chunk being processed - NOT the array length(s).
 * h: will never be more than 8, and increases by *2 during suffix sort (h += h) */
static void split(int64_t * I, int64_t * V, int64_t arraylen, int64_t start, int64_t len,
		  int64_t h)
{
	int64_t i, j, k, x, tmp, jj, kk;

	if (len < 16) {
		for (k = start; k < start + len; k += j) {
			j = 1;
			x = V[I[k] + h];
			for (i = 1; k + i < start + len; i++) {
				/* This should never get out of bounds, BUT it
				 * would be good to know if it ever happens */
				if ((I[k + i] + h) > arraylen) {
					LOG_ERROR(NULL, "Array out of bounds: ", class_mem_access, "%lu > %lu\n", I[k + i] + h, arraylen);
				} else if ((I[k + i] + h) < 0) {
					LOG_ERROR(NULL, "Array out of bounds: ", class_mem_access, "%lu < 0\n", I[k + i] + h);
				}

				if (V[I[k + i] + h] < x) {
					x = V[I[k + i] + h];
					j = 0;
				};
				if (V[I[k + i] + h] == x) {
					tmp = I[k + j];
					I[k + j] = I[k + i];
					I[k + i] = tmp;
					j++;
				};
			};
			for (i = 0; i < j; i++)
				V[I[k + i]] = k + j - 1;
			if (j == 1)
				I[k] = -1;
		};
		return;
	};

	x = V[I[start + len / 2] + h];
	jj = 0;
	kk = 0;
	for (i = start; i < start + len; i++) {
		if (V[I[i] + h] < x)
			jj++;
		if (V[I[i] + h] == x)
			kk++;
	};
	jj += start;
	kk += jj;

	i = start;
	j = 0;
	k = 0;
	while (i < jj) {
		if (V[I[i] + h] < x) {
			i++;
		} else if (V[I[i] + h] == x) {
			tmp = I[i];
			I[i] = I[jj + j];
			I[jj + j] = tmp;
			j++;
		} else {
			tmp = I[i];
			I[i] = I[kk + k];
			I[kk + k] = tmp;
			k++;
		};
	};

	while (jj + j < kk) {
		if (V[I[jj + j] + h] == x) {
			j++;
		} else {
			tmp = I[jj + j];
			I[jj + j] = I[kk + k];
			I[kk + k] = tmp;
			k++;
		};
	};

	if (jj > start)
		split(I, V, arraylen, start, jj - start, h);

	for (i = 0; i < kk - jj; i++)
		V[I[jj + i]] = kk - 1;
	if (jj == kk - 1)
		I[jj] = -1;

	if (start + len > kk)
		split(I, V, arraylen, kk, start + len - kk, h);
}

/* The old_data (previous file data) is passed into this suffix sort and sorted
 * accordingly using the I and V arrays, which are both of length oldsize +1. */
static int qsufsort(int64_t * I, int64_t * V, u_char * old, int64_t oldsize)
{
	int64_t buckets[QSUF_BUCKET_SIZE];
	int64_t i, h, len;

	for (i = 0; i < QSUF_BUCKET_SIZE; i++)
		buckets[i] = 0;
	for (i = 0; i < oldsize; i++)
		buckets[old[i]]++;
	for (i = 1; i < QSUF_BUCKET_SIZE; i++)
		buckets[i] += buckets[i - 1];
	for (i = QSUF_BUCKET_SIZE - 1; i > 0; i--)
		buckets[i] = buckets[i - 1];
	buckets[0] = 0;

	for (i = 0; i < oldsize; i++) {
		if (buckets[old[i]] > oldsize + 1) {
			LOG_ERROR(NULL, "qsufsort(): array I out of bounds", class_mem_access, "\\*buckets[old[i]]=\"%d\", max=\"255\"*\\", buckets[old[i]], oldsize + 1);
			return -1;
		}
		I[++buckets[old[i]]] = i;
	}

	for (i = 0; i < oldsize; i++)
		V[i] = buckets[old[i]];
	V[oldsize] = 0;
	for (i = 1; i < QSUF_BUCKET_SIZE; i++)
		if (buckets[i] == buckets[i - 1] + 1)
			I[buckets[i]] = -1;
	I[0] = -1;

	for (h = 1; I[0] != -(oldsize + 1); h += h) {
		len = 0;
		for (i = 0; i < oldsize + 1;) {
			if (I[i] < 0) {
				len -= I[i];
				i -= I[i];
			} else {
				if (len)
					I[i - len] = -len;
				len = V[I[i]] + 1 - i;
				split(I, V, oldsize, i, len, h);
				i += len;
				len = 0;
			};
		};
		if (len)
			I[i - len] = -len;
	};

	for (i = 0; i < oldsize + 1; i++)
		I[V[i]] = i;

	return 0;
}

static int64_t matchlen(u_char * old, int64_t oldsize, u_char * new,
			int64_t newsize)
{
	int64_t i;

	for (i = 0; (i < oldsize) && (i < newsize); i++)
		if (old[i] != new[i])
			break;

	return i;
}

static int64_t search(int64_t * I, u_char * old, int64_t oldsize,
		      u_char * new, int64_t newsize, int64_t st, int64_t en,
		      int64_t * pos)
{
	int64_t x, y;

	if (en - st < 2) {
		x = matchlen(old + I[st], oldsize - I[st], new, newsize);
		y = matchlen(old + I[en], oldsize - I[en], new, newsize);

		if (x > y) {
			*pos = I[st];
			return x;
		} else {
			*pos = I[en];
			return y;
		}
	};

	x = st + (en - st) / 2;
	if (memcmp(old + I[x], new, MIN(oldsize - I[x], newsize)) < 0) {
		return search(I, old, oldsize, new, newsize, x, en, pos);
	} else {
		return search(I, old, oldsize, new, newsize, st, x, pos);
	};
}

static inline void offtout(int64_t x, u_char * buf)
{
	*((int64_t *) buf) = htole64(x);
}

/* zlib provides compress2, which deflates to deflate (zlib) format. This is
 * unfortunately distinct from gzip format in that the headers wrapping the
 * decompressed data are different. gbspatch reads gzip-compressed data using
 * the file-oriented gzread interface, which only supports gzip format.
 * compress2gzip is identical to zlib's compress2 except that it produces gzip
 * output compatible with gzread. This change is achieved by calling
 * deflateInit2 instead of deflateInit and specifying 31 for windowBits;
 * numbers greater than 15 cause the addition of a gzip wrapper. */

static int compress2gzip(Bytef * dest, size_t * destLen,
			 const Bytef * source, uLong sourceLen, int level)
{
	z_stream stream;
	int err;

	stream.next_in = (Bytef *) source;
	stream.avail_in = (uInt) sourceLen;

	stream.next_out = dest;
	stream.avail_out = (uInt) * destLen;
	if ((uLong) stream.avail_out != *destLen)
		return Z_BUF_ERROR;

	stream.zalloc = (alloc_func) 0;
	stream.zfree = (free_func) 0;
	stream.opaque = (voidpf) 0;

	err = deflateInit2(&stream,
			   level, Z_DEFLATED, 31, 8, Z_DEFAULT_STRATEGY);
	if (err != Z_OK)
		return err;

	err = deflate(&stream, Z_FINISH);
	if (err != Z_STREAM_END) {
		deflateEnd(&stream);
		return err == Z_OK ? Z_BUF_ERROR : err;
	}
	*destLen = stream.total_out;

	err = deflateEnd(&stream);
	return err;
}

static pthread_mutex_t lzma_mutex = PTHREAD_MUTEX_INITIALIZER;

static uint64_t count_nonzero(unsigned char *buf, uint64_t len)
{
	uint64_t count = 0;
	uint64_t i = 0;
	while (i < len) {
		if (buf[i])
			count++;
		i++;
	}
	return count;
}


/* Recompress buf of size buf_len using a supported algorithm. The smallest version is
 * used. The original uncompressed variant may be the smallest. Returns a
 * number identifying the encoding according to enum BSDIFF_ENCODINGS.
 * If the original uncompressed variant is not smallest, it is freed. The caller
 * must free any buf after this function returns. */
static char make_small(u_char ** buf, uint64_t * buf_len, int enc, char *file, char *blockname)
{
	u_char *source = *buf;
	uint64_t source_len = *buf_len;
#ifdef SWUPD_WITH_BZIP2
	u_char *bz2;
	unsigned int bz2_len;
	int bz2_err;
	int bzip_penalty = 512;
#endif
	u_char *gz, *lzma;
	size_t gz_len, lzma_len, lzma_pos;
	int gz_err;
	lzma_ret lzma_err;
	lzma_check lzma_ck;
	char smallest;

	uint64_t unc_size = 0, bzip_size = 0, gzip_size = 0, xz_size = 0, nonzero = 0;

	smallest = BSDIFF_ENC_NONE;

	if (enc == BSDIFF_ENC_NONE || source_len == 0) {
		LOG_DEBUG(NULL, "delta stats", class_stats, "piece %s: Uncompressed %8llu  Bzip2 %8llu  gzip %8llu  xz %8llu  nonzero bytes %8llu   --> %s (%s)",
		blockname, unc_size, bzip_size, gzip_size, xz_size, nonzero, algos[(int)smallest], file);
		return smallest;
	}
	unc_size =  *buf_len;

	nonzero = count_nonzero(source, source_len);

	/* if it's an all-zeros block, we're done */
	if (!nonzero) {
		if ((enc == BSDIFF_ENC_ANY) &&
		    ((strncmp(blockname, "diff", 4) == 0) ||
		     (strncmp(blockname, "extra", 5) == 0))) {
			uint64_t *zeros;
			zeros = malloc(sizeof(uint64_t));
			assert(zeros);
			*zeros = source_len;
			free(source);
			*buf = (u_char *) zeros;
			*buf_len = sizeof(uint64_t);
			LOG_DEBUG(NULL, "delta stats", class_stats, "piece %s: Uncompressed %8llu  Bzip2 %8llu  gzip %8llu  xz %8llu  nonzero bytes %8llu   --> %s (%s)",
					blockname, unc_size, bzip_size, gzip_size, xz_size, nonzero, algos[(int)smallest], file);
			return BSDIFF_ENC_ZEROS;
		}
#ifdef SWUPD_WITH_BZIP2
		bzip_penalty = 0;
#endif
	}

	/* we do gzip first. it's fast on decompression and does quite well on compression */
	gz_len = source_len + 1;
	gz = malloc(gz_len);
	gz_err = compress2gzip(gz, &gz_len, source, source_len, 9);
	if (gz_err == Z_OK) {
		gzip_size = gz_len;

		if (gz_len < (unsigned int)*buf_len  &&
		    (enc == BSDIFF_ENC_ANY || enc == BSDIFF_ENC_GZIP)) {
			smallest = BSDIFF_ENC_GZIP;
			*buf = gz;
			*buf_len = gz_len;
		} else {
			free(gz);
			gz = NULL;
		}
	} else if (gz_err == Z_BUF_ERROR) {
		free(gz);
		gz = NULL;
	} else {
		LOG_ERROR(NULL, "bsdiff gzip error: ", class_file_compression, "\\*gz_err=\"%d\"*\\", gz_err);
	}


	/* xz/lzma are slower on decompression, but esp for bigger files, compress better */
	pthread_mutex_lock(&lzma_mutex);
	lzma_len = source_len + 1000;
	lzma = malloc(lzma_len);
	lzma_pos = 0;

	/* Equivalent to the options used by xz -9 -e. */
	/*
	 * We'd like to set LZMA_CHECK_NONE, since we do our own sha based checksum at the end.
	 * However, that seems to generate undecodable compressed blocks, so we'll just do the
	 * smallest and cheapest alternative to _NONE, which is CRC32
	 */
	lzma_ck = LZMA_CHECK_CRC32;
	if (!lzma_check_is_supported(lzma_ck))
		lzma_ck = LZMA_CHECK_CRC32;
	lzma_err = lzma_easy_buffer_encode(9 | LZMA_PRESET_EXTREME,
					   lzma_ck, NULL,
					   source, source_len,
					   lzma, &lzma_pos, lzma_len);
	if (lzma_err == LZMA_OK) {
		xz_size = lzma_pos;
		if ( 1.01 * lzma_pos + 64 < *buf_len  &&
		    (enc == BSDIFF_ENC_ANY || enc == BSDIFF_ENC_XZ)) {
			smallest = BSDIFF_ENC_XZ;
			*buf = lzma;
			*buf_len = lzma_pos;
		} else {
			free(lzma);
			lzma = NULL;
		}
	} else if (lzma_err == LZMA_BUF_ERROR) {
		free(lzma);
		lzma = NULL;
	} else {
		LOG_ERROR(NULL, "bsdiff lzma error: ", class_file_compression, "\\*lzma_err=\"%d\"*\\", lzma_err);
	}

	pthread_mutex_unlock(&lzma_mutex);



#ifdef SWUPD_WITH_BZIP2
	/* bzip2 is the slowed of the set on decompress, but for some times of inputs, does really really well */
	bz2_len = source_len + 1;
	bz2 = malloc(bz2_len);
	bz2_err =
	    BZ2_bzBuffToBuffCompress((char *)bz2, &bz2_len, (char *)source,
				     source_len, 9, 0, 0);
	if (bz2_err == BZ_OK) {
		bzip_size = bz2_len;

		/* we add a 5% + 1/2 Kb penalty to bzip2, due to the high cost on the client */
		if (1.05 * bz2_len + bzip_penalty < (unsigned int)*buf_len &&
		    (enc == BSDIFF_ENC_ANY || enc == BSDIFF_ENC_BZIP2)) {
			smallest = BSDIFF_ENC_BZIP2;
			*buf = bz2;
			*buf_len = bz2_len;
		} else {
			free(bz2);
			bz2 = NULL;
		}
	} else if (bz2_err == BZ_OUTBUFF_FULL) {
		free(bz2);
		bz2 = NULL;
	} else {
		LOG_ERROR(NULL, "bsdiff bz2 error: ", class_file_compression, "\\*bz2_err=\"%d\"*\\", bz2_err);
	}
#endif


	if (smallest != BSDIFF_ENC_NONE) {
		free(source);
	}

#ifdef SWUPD_WITH_BZIP2
	if (smallest != BSDIFF_ENC_BZIP2) {
		free(bz2);
	}
#endif
	if (smallest != BSDIFF_ENC_GZIP) {
		free(gz);
	}
	if (smallest != BSDIFF_ENC_XZ) {
		free(lzma);
	}

	LOG_DEBUG(NULL, "delta stats", class_stats, "piece %s: Uncompressed %8llu  Bzip2 %8llu  gzip %8llu  xz %8llu  nonzero bytes %8llu   --> %s (%s)",
		blockname, unc_size, bzip_size, gzip_size, xz_size, nonzero, algos[(int)smallest], file);
	return smallest;
}

/* returns <0 on error (hopefully logging/printfing something useful), 0 on
 * success, and 1 on "success" with a FULLDL header */
int make_bsdiff_delta(char *old_filename, char *new_filename, char *delta_filename, int enc)
{
	int fd;
	u_char *old_data, *new_data;
	int64_t oldsize, newsize;
	int64_t *I, *V;
	int64_t scan;
	int64_t pos = 0;
	int64_t len;
	int64_t lastscan, lastpos, lastoffset;
	int64_t oldscore, scsc;
	int64_t s, Sf, lenf, Sb, lenb;
	int64_t overlap, Ss, lens;
	int64_t i;
	uint64_t cblen, dblen, eblen;
	u_char *cb, *db, *eb;
	struct stat new_stat;
	struct stat old_stat;
	int ret, smallfile;
	off_t first_block;
	int c_enc, d_enc, e_enc;
	enc_flags_t encodings;

	struct header_v20 large_header;
	struct header_v21 small_header;
	FILE *pf;

	ret = lstat(old_filename, &old_stat);
	if (ret < 0) {
		LOG_ERROR(NULL, "stat failure", class_file_io, "\\*old_filename=\"%s\"*\\", old_filename);
		return -1;
	}

	ret = lstat(new_filename, &new_stat);
	if (ret < 0) {
		LOG_ERROR(NULL, "stat failure", class_file_io, "\\*new_filename=\"%s\"*\\", new_filename);
		return -1;
	}

	if (S_ISDIR(new_stat.st_mode) || S_ISDIR(old_stat.st_mode)) {
		/* no delta on symlinks ! */
		return -1;
	}

	/* Check if xattrs have changed and refuse to create a diff in this
	 * case. */
	if (xattrs_compare(old_filename, new_filename) != 0) {
		LOG_INFO(NULL, "xattrs have changed, don't create diff ", class_xattrs, "%s", new_filename);
		return -1;
	}

	if ((new_stat.st_size < 65536) && (old_stat.st_size < 65536))
		smallfile=1;
	else
		smallfile=0;

	fd = open(old_filename, O_RDONLY, 0);
	if (fd < 0)
		return -1;
	if (fstat(fd, &old_stat) != 0) {
		LOG_ERROR(NULL, "Cannot stat file ", class_file_io, "\\*filename=\"%s\"*\\", old_filename);
		close(fd);
		return -1;
	}

	oldsize = old_stat.st_size;

	/* We may start with an empty file, if so, just mark it for full download
	 * to throw into the pack. In the case that newfile is <200, it will quit
	 * and ask for fulldownload, so we only need to check oldsize */
	if (oldsize == 0) {
		LOG_INFO(NULL, "oldsize is 0, send full file instead of diff \n", class_file_io, "");
		memset(&small_header, 0, sizeof(struct header_v21));
		memcpy(&small_header.magic, BSDIFF_HDR_FULLDL, 8);
		if ((pf = fopen_exclusive(delta_filename)) == NULL) {
			LOG_ERROR(NULL, "bsdiff error on delta file open ",
				class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
			close(fd);
			return -1;
		}
		if (fwrite(&small_header, 8, 1, pf) != 1) {
			LOG_ERROR(NULL, "bsdiff error on delta FULLDL fwrite ",
				class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
			fclose(pf);
			close(fd);
			return -1;
		}
		fclose(pf);
		close(fd);
		return 1;
	}

	/* TODO: investigate why this needs to be +1 to not overrun; coverity complains
	 * that we overrun old_data when we calculate differences otherwise. Tenatively,
	 * since this is used in qsufsort, it may need to be +1 like I and V because of
	 * a sentinel byte when sorting. However, newsize does not cause any overruns
	 * when created with the regular file size */
	old_data = mmap(NULL, oldsize + 1, PROT_READ, MAP_SHARED, fd, 0);
	close(fd);

	if (old_data == MAP_FAILED) {
		LOG_ERROR(NULL, "Couldn't mmap full file ", class_mem_alloc, "\\*filename=\"%s\"*\\", old_filename);
		old_data = NULL;
		return -1;
	}

	/* These arrays are size + 1 because suffix sort needs space for the
	 * data + 1 sentinel element to actually do the sorting. Not because
	 * oldsize might be 0. */
	if ((I = malloc((oldsize + 1) * sizeof(int64_t))) == NULL) {
		munmap(old_data, oldsize);
		return -1;
	}
	if ((V = malloc((oldsize + 1) * sizeof(int64_t))) == NULL) {
		munmap(old_data, oldsize);
		free(I);
		return -1;
	}

	if (qsufsort(I, V, old_data, oldsize) != 0) {
		munmap(old_data, oldsize);
		free(I);
		free(V);
		return -1;
	}

	free(V);

	if ((fd = open(new_filename, O_RDONLY, 0)) < 0) {
		LOG_ERROR(NULL, "bsdiff error on newfile open", class_file_io, "\\*new_full_filename=\"%s\"*\\", new_filename);
		munmap(old_data, oldsize);
		free(I);
		return -1;
	}

	if (fstat(fd, &new_stat) != 0) {
		LOG_ERROR(NULL, "Cannot stat file ", class_file_io, "\\*filename=\"%s\"*\\", new_filename);
		munmap(old_data, oldsize);
		free(I);
		close(fd);
		return -1;
	}

		newsize = new_stat.st_size;

	/* Note: testing this to see how diffs between small files affect
	 * updates. Small files seem to cause some problems between certain
	 * files (buffer overrun/underrun perhaps). We try to avoid this
	 * preemptively by marking the file as a FULLDL file and not create
	 * a bsdiff at all, which leaves us with small files that may fail
	 * the "is bsdiff < 90% of newfile size" check that would otherwise
	 * be performed later on.
	 */
	if (newsize < 200) {
		LOG_DEBUG(NULL, "bsdiff newfile size < 200 bytes, marking for full download",
				class_stats, "\\*new_full_filename=\"%s\"*\\", new_filename);
		memset(&small_header, 0, sizeof(struct header_v21));
		memcpy(&small_header.magic, BSDIFF_HDR_FULLDL, 8);
		if ((pf = fopen_exclusive(delta_filename)) == NULL) {
			LOG_ERROR(NULL, "bsdiff error on delta file open",
					class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
			close(fd);
			munmap(old_data, oldsize);
			free(I);
			return -1;
		}
		if (fwrite(&small_header, 8, 1, pf) != 1) {
			LOG_ERROR(NULL, "bsdiff error on delta FULLDL fwrite ",
					class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
			fclose(pf);
			close(fd);
			munmap(old_data, oldsize);

			free(I);
			return -1;
		}
		fclose(pf);
		close(fd);
		munmap(old_data, oldsize);
		free(I);
		return 1;
	}

	if ((new_data = malloc(newsize)) == NULL) {
		LOG_ERROR(NULL, "bsdiff error on new_data malloc", class_mem_alloc, "\\*new_full_filename=\"%s\"*\\", new_filename);
		close(fd);
		munmap(old_data, oldsize);
		free(I);
		return -1;
	}

	if (pread(fd, new_data, newsize, 0) != newsize) {
		LOG_ERROR(NULL, "bsdiff error on newfile read", class_file_io, "\\*new_full_filename=\"%s\"*\\", new_filename);
		close(fd);
		munmap(old_data, oldsize);
		free(new_data);
		free(I);
		return -1;
	}
	if (close(fd) == -1) {
		LOG_ERROR(NULL, "bsdiff error on newfile close", class_file_io, "\\*new_full_filename=\"%s\"*\\", new_filename);
		munmap(old_data, oldsize);
		free(new_data);
		free(I);
		return -1;
	}

	/* we can write 3 8 byte tupples extra, so allocate some headroom */
	if ((cb = malloc(newsize + 25)) == NULL) {
		munmap(old_data, oldsize);
		free(new_data);
		free(I);
		return -1;
	}
	if ((db = malloc(newsize + 25)) == NULL) {
		munmap(old_data, oldsize);
		free(new_data);
		free(cb);
		free(I);
		return -1;
	}
	if ((eb = malloc(newsize + 25)) == NULL) {
		munmap(old_data, oldsize);
		free(new_data);
		free(cb);
		free(db);
		free(I);
		return -1;
	}
	cblen = 0;
	dblen = 0;
	eblen = 0;

	/* Compute the differences */
	scan = 0;
	len = 0;
	lastscan = 0;
	lastpos = 0;
	lastoffset = 0;
	while (scan < newsize) {
		oldscore = 0;

		for (scsc = scan += len; scan < newsize; scan++) {
			len =
			    search(I, old_data, oldsize, new_data + scan, newsize - scan,
				   0, oldsize, &pos);

			for (; scsc < scan + len; scsc++)
				if ((scsc + lastoffset < oldsize) &&
				    (old_data[scsc + lastoffset] == new_data[scsc]))
					oldscore++;

			if (((len == oldscore) && (len != 0)) ||
			    (len > oldscore + 8))
				break;

			if ((scan + lastoffset < oldsize) &&
			    (old_data[scan + lastoffset] == new_data[scan]))
				oldscore--;
		};

		if ((len != oldscore) || (scan == newsize)) {
			s = 0;
			Sf = 0;
			lenf = 0;
			for (i = 0;
			     (lastscan + i < scan)
			     && (lastpos + i < oldsize);) {
				if (old_data[lastpos + i] == new_data[lastscan + i])
					s++;
				i++;
				if (s * 2 - i > Sf * 2 - lenf) {
					Sf = s;
					lenf = i;
				};
			};

			lenb = 0;
			if (scan < newsize) {
				s = 0;
				Sb = 0;
				for (i = 1;
				     (scan >= lastscan + i) && (pos >= i);
				     i++) {
					if (old_data[pos - i] == new_data[scan - i])
						s++;
					if (s * 2 - i > Sb * 2 - lenb) {
						Sb = s;
						lenb = i;
					};
				};
			};

			if (lastscan + lenf > scan - lenb) {
				overlap = (lastscan + lenf) - (scan - lenb);
				s = 0;
				Ss = 0;
				lens = 0;
				for (i = 0; i < overlap; i++) {
					if (new_data[lastscan + lenf - overlap + i]
					    ==
					    old_data[lastpos + lenf - overlap + i])
						s++;
					if (new_data[scan - lenb + i] ==
					    old_data[pos - lenb + i])
						s--;
					if (s > Ss) {
						Ss = s;
						lens = i + 1;
					};
				};

				lenf += lens - overlap;
				lenb -= lens;
			};

			for (i = 0; i < lenf; i++)
				db[dblen + i] =
				    new_data[lastscan + i] - old_data[lastpos + i];
			for (i = 0; i < (scan - lenb) - (lastscan + lenf); i++)
				eb[eblen + i] = new_data[lastscan + lenf + i];

			dblen += lenf;
			eblen += (scan - lenb) - (lastscan + lenf);

			if ((int64_t)(cblen + 24) > (newsize + 25)){
				LOG_ERROR(NULL, "control block overflow", class_delta,
					"\\*delta_filename=\"%s\",old_filename=\"%s\",new_filename=\"%s\",cblen=\"%d\",newsize=\"%d\"*\\",
					delta_filename, old_filename, new_filename, cblen, newsize);
				munmap(old_data, oldsize);
				free(new_data);
				free(cb);
				free(db);
				free(eb);
				free(I);
				return -1;
			}

			offtout(lenf, cb + cblen);
			cblen += 8;

			offtout((scan - lenb) - (lastscan + lenf), cb + cblen);
			cblen += 8;

			offtout((pos - lenb) - (lastpos + lenf), cb + cblen);
			cblen += 8;

			lastscan = scan - lenb;
			lastpos = pos - lenb;
			lastoffset = pos - scan;
		};
	};
	free(I);

	c_enc = make_small(&cb, &cblen, enc, new_filename, "control");
	d_enc = make_small(&db, &dblen, enc, new_filename, "diff   ");
	e_enc = make_small(&eb, &eblen, enc, new_filename, "extra  ");

	if ((!cb) || (!db) || (!eb )) {
		LOG_ERROR(NULL, "bsdiff make_small errors", class_file_compression, "\\*delta_filename=\"%s\"*\\", delta_filename);
		ret = -1;
		goto fulldl_free;
	}

	/* Create the patch file */
	if ((pf = fopen_exclusive(delta_filename)) == NULL) {
		LOG_ERROR(NULL, "bsdiff error opening delta file ", class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
		ret = -1;
		goto fulldl_free;
	}

	if (smallfile && (cblen < 256) && (dblen < 65536) && (eblen < 65536)){
		memset(&small_header, 0, sizeof(struct header_v21));
		memcpy(&small_header.magic, BSDIFF_HDR_MAGIC_V21, 8);

		/* in the future we may need to push first_block out further to squeeze
		 * something extra into the header */
		first_block = sizeof(struct header_v21);
		small_header.offset_to_first_block = first_block;
		small_header.control_length = cblen;
		small_header.diff_length = dblen;
		small_header.extra_length = eblen;
		small_header.old_file_length = oldsize;
		small_header.new_file_length = newsize;
		small_header.file_mode = new_stat.st_mode;
		small_header.file_owner = new_stat.st_uid;
		small_header.file_group = new_stat.st_gid;

		cblock_set_enc(&small_header.encoding, c_enc);
		dblock_set_enc(&small_header.encoding, d_enc);
		eblock_set_enc(&small_header.encoding, e_enc);
		encodings=small_header.encoding;

		if ((first_block + cblen + dblen + eblen > 0.90 * newsize)
		     && (enc != BSDIFF_ENC_NONE)) { /* tune */
			memcpy(&small_header.magic, BSDIFF_HDR_FULLDL, 8);
			ret = 1;
			if (fwrite(&small_header, 8, 1, pf) != 1) {
				LOG_ERROR(NULL, "bsdiff error on delta FULLDL fwrite ", class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
				ret = -1;
				goto fulldl_close_free;
			}
			bsdiff_fulldl++;
			goto fulldl_close_free;
		}

		if (fwrite(&small_header, sizeof(struct header_v21), 1, pf) != 1) {
			LOG_ERROR(NULL, "bsdiff error on delta file header v21 fwrite ", class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
			ret = -1;
			goto fulldl_close_free;
		}
		/* if (fseek(pf, first_block, SEEK_SET) == -1) {
		 *	LOG(NULL, "bsdiff error padding header v21", "%s", delta_filename);
		 * }
		 */
	} else {
		smallfile=0;

		memset(&large_header, 0, sizeof(struct header_v20));
		memcpy(&large_header.magic, BSDIFF_HDR_MAGIC_V20, 8);

		/* in the future we may need to push this out further to squeeze
		 * something extra into the header */
		first_block = sizeof(struct header_v20);
		large_header.offset_to_first_block = first_block;
		large_header.control_length = cblen;
		large_header.diff_length = dblen;
		large_header.extra_length = eblen;
		large_header.old_file_length = oldsize;
		large_header.new_file_length = newsize;
		large_header.file_mode = new_stat.st_mode;
		large_header.file_owner = new_stat.st_uid;
		large_header.file_group = new_stat.st_gid;

		cblock_set_enc(&large_header.encoding, c_enc);
		dblock_set_enc(&large_header.encoding, d_enc);
		eblock_set_enc(&large_header.encoding, e_enc);
		encodings=large_header.encoding;

		if ((first_block + cblen + dblen + eblen > 0.90 * newsize)
		    && (enc != BSDIFF_ENC_NONE)) { /* tune */
			memcpy(&large_header.magic, BSDIFF_HDR_FULLDL, 8);
			ret = 1;
			if (fwrite(&large_header, 8, 1, pf) != 1) {
				LOG_ERROR(NULL, "bsdiff error on delta FULLDL fwrite ", class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
				ret = -1;
				goto fulldl_close_free;
			}
			bsdiff_fulldl++;
			goto fulldl_close_free;
		}

		if (fwrite(&large_header, sizeof(struct header_v20), 1, pf) != 1) {
			LOG_ERROR(NULL, "bsdiff error on delta file header v20 fwrite ", class_file_io, "\\*delta_filename=\"%s\"*\\", delta_filename);
			ret = -1;
			goto fulldl_close_free;
		}
		/* if (fseek(pf, small_header.offset_to_first_block, SEEK_SET) == -1) {
		 *	LOG(NULL, "bsdiff error padding header v20", "%s", delta_filename);
		 * }
		 */
	}

	if (fwrite(cb, cblen, 1, pf) != 1) {
		LOG_ERROR(NULL, "bsdiff error in cb fwrite", class_file_io, "");
		ret = -1;
		goto fulldl_close_free;
	}
	if (dblen > 0 && fwrite(db, dblen, 1, pf) != 1) {
		LOG_ERROR(NULL, "bsdiff error in db fwrite", class_file_io, "");
		ret = -1;
		goto fulldl_close_free;
	}
	if (eblen > 0 && fwrite(eb, eblen, 1, pf) != 1) {
		LOG_ERROR(NULL, "bsdiff error in eb fwrite", class_file_io, "");
		ret = -1;
		goto fulldl_close_free;
	}

	bsdiff_files ++;
	bsdiff_newbytes += newsize;
	bsdiff_outputbytes += first_block + cblen + dblen + eblen;

	if (cblock_get_enc(encodings) == BSDIFF_ENC_NONE) bsdiff_none ++;
	if (dblock_get_enc(encodings) == BSDIFF_ENC_NONE) bsdiff_none ++;
	if (eblock_get_enc(encodings) == BSDIFF_ENC_NONE) bsdiff_none ++;
	if (cblock_get_enc(encodings) == BSDIFF_ENC_GZIP) bsdiff_gzip ++;
	if (dblock_get_enc(encodings) == BSDIFF_ENC_GZIP) bsdiff_gzip ++;
	if (eblock_get_enc(encodings) == BSDIFF_ENC_GZIP) bsdiff_gzip ++;
	if (cblock_get_enc(encodings) == BSDIFF_ENC_BZIP2) bsdiff_bzip2 ++;
	if (dblock_get_enc(encodings) == BSDIFF_ENC_BZIP2) bsdiff_bzip2 ++;
	if (eblock_get_enc(encodings) == BSDIFF_ENC_BZIP2) bsdiff_bzip2 ++;
	if (cblock_get_enc(encodings) == BSDIFF_ENC_XZ) bsdiff_xz ++;
	if (dblock_get_enc(encodings) == BSDIFF_ENC_XZ) bsdiff_xz ++;
	if (eblock_get_enc(encodings) == BSDIFF_ENC_XZ) bsdiff_xz ++;
	if (dblock_get_enc(encodings) == BSDIFF_ENC_ZEROS) bsdiff_zeros ++;
	if (eblock_get_enc(encodings) == BSDIFF_ENC_ZEROS) bsdiff_zeros ++;

	ret = 0;

fulldl_close_free:
	if (fclose(pf)) {
		LOG_ERROR(NULL, "bsdiff error in fclose", class_file_io, "");
		ret = -1;
	}
fulldl_free:
	/* Free the memory we used */
	munmap(old_data, oldsize);
	free(new_data);
	free(cb);
	free(db);
	free(eb);

	return ret;
}
